package com.packtpub.cinemasservice.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Movie {

    private Integer id;
    private String name;

}
