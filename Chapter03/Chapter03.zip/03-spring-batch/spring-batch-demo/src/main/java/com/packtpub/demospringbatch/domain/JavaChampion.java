package com.packtpub.demospringbatch.domain;

import lombok.Data;

@Data
public class JavaChampion {

    private String firstName;

    private String lastName;

    private String country;

    private Integer year;

}
