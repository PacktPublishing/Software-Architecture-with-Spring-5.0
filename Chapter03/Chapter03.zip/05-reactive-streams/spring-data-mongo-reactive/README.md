# Reactive  Spring  data

This project show how Spring data can work using a reactive approach. The project has a test using Mongo DB:

- SpringDataMongoReactiveApplicationTests