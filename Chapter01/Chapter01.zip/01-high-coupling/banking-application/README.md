# High coupling

This project example consist of some classes which are highly couple.
A couple of classes has been created containing unit tests for the implemented code:

- BankStatementServiceTest
- CustomerServiceTest